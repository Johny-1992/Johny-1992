
# HumanGo (HGO) Site

This is the official site template for HumanGo (HGO), including:
- Multilingual-ready landing page
- Telegram bot integration link
- Share button for WhatsApp virality

## How to Use

1. Host `web/` folder on Vercel, Netlify, or GitHub Pages.
2. Host `bot/` directory separately on Railway/Render if you use a Python backend.
3. Customize `index.html` as needed.

Peace and unity through decentralized technology.
