from fastapi import FastAPI, Request
import uvicorn
import os
import httpx
from pydantic import BaseModel
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

app = FastAPI()

BOT_TOKEN = os.getenv("BOT_TOKEN")
TON_API_KEY = os.getenv("TON_API_KEY")
MAIN_WALLET = os.getenv("MAIN_WALLET_ADDRESS")
CONTRACT_HGO = os.getenv("HGO_CONTRACT_ADDRESS")
OPENAI_KEY = os.getenv("OPENAI_API_KEY")

TELEGRAM_API = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
TON_API_BASE = "https://toncenter.com/api/v2/"

class TelegramUpdate(BaseModel):
    message: dict

@app.post("/webhook")
async def webhook(update: TelegramUpdate):
    message = update.message
    chat_id = message["chat"]["id"]
    user_id = message["from"]["id"]
    text = message.get("text", "").lower()

    if "/start" in text:
        tx = await send_hgo(user_id)
        response = f"👋 Bienvenue sur HumanGo!\n\n🎁 10 HGO envoyés à ton wallet !\n\n🚀 Invite d'autres utilisateurs pour gagner encore plus."
    elif "invite" in text:
        response = "🔗 Ton lien de parrainage arrive bientôt !"
    elif "aide" in text:
        response = "ℹ️ Tape /start pour recevoir 10 HGO.\nTape 'invite' pour parrainer."
    else:
        response = "🤖 Je ne comprends pas. Tape 'aide'."

    await httpx.post(TELEGRAM_API, json={"chat_id": chat_id, "text": response})
    return {"ok": True}

async def send_hgo(user_id):
    print(f"Transaction HGO de 10 tokens pour utilisateur {user_id}")
    return True

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
